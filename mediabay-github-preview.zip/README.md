# MediaBay — Full Website Preview

This is a **single-file GitHub Pages preview** of the complete MediaBay website.

## Publish on GitHub

1. Create a GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select the branch containing `index.html` and the `/ (root)` folder.
6. Save and open the GitHub Pages URL.

The preview contains:
- Home / landing page
- Strategy & Brand
- Websites & Landing
- E-commerce
- Social & Content
- SEO, Google & Advertising
- AI & Automation
- Mobility & Phygital

The pages are embedded in the single `index.html`, so there are no missing relative-page links on GitHub Pages.
